// A covered handoff persists across documents; reveal only after the new page is ready.
(()=>{
 const root=document.documentElement,system=matchMedia('(prefers-reduced-motion: reduce)');
 const requested=new URLSearchParams(location.search).get('motion');
 if(['on','off'].includes(requested)){try{localStorage.setItem('site-motion',requested)}catch{}}
 const enabled=()=>{let p='system';try{p=localStorage.getItem('site-motion')||'system'}catch{};return p==='on'||(p!=='off'&&!system.matches)};
 const sync=()=>root.dataset.uiMotion=enabled()?'on':'off';
 sync();system.addEventListener('change',sync);
 const key='site-navigation';
 history.scrollRestoration='manual';
 const describe=url=>{
  const section=url.pathname.split('/')[2]||'home';
  return {light:section==='projects',surface:section==='projects'?'#f4f4f1':'#111210'};
 };
 let navigating=false,overlay,animations=[],recoveryTimer;
 let documentURL=new URL(location.href);
 const sameDocument=url=>url.pathname===documentURL.pathname&&url.search===documentURL.search;
 let scrollTween;
 const stopScroll=()=>{scrollTween?.kill();scrollTween=null};
 ['wheel','touchstart','pointerdown'].forEach(type=>window.addEventListener(type,stopScroll,{passive:true}));
 window.addEventListener('keydown',event=>{if(['ArrowDown','ArrowUp','PageDown','PageUp','Home','End',' '].includes(event.key))stopScroll()});
 const scrollWithin=(url,position)=>{
  stopScroll();
  let target=null;try{target=url.hash?document.getElementById(decodeURIComponent(url.hash.slice(1))):null}catch{}
  if(target){
   const details=target.querySelector('details');if(target.classList.contains('trace-entry')&&details)details.open=true;
   position=[scrollX,target.getBoundingClientRect().top+scrollY-(parseFloat(getComputedStyle(root).scrollPaddingTop)||0)-(parseFloat(getComputedStyle(target).scrollMarginTop)||0)];
   if(!target.hasAttribute('tabindex')){target.setAttribute('tabindex','-1');target.addEventListener('blur',()=>target.removeAttribute('tabindex'),{once:true})}
   target.focus({preventScroll:true});
  }
  const top=Math.max(0,Math.min(position[1],root.scrollHeight-innerHeight));
  if(!enabled()||!window.gsap){window.scrollTo({left:position[0],top,behavior:enabled()?'smooth':'instant'});return}
  const point={x:scrollX,y:scrollY},distance=Math.abs(top-scrollY);
  scrollTween=gsap.to(point,{x:position[0],y:top,duration:Math.min(1.35,.65+distance/5000),ease:'power2.inOut',onUpdate:()=>window.scrollTo({left:point.x,top:point.y,behavior:'instant'}),onComplete:()=>{scrollTween=null}});
 };
 const reset=()=>{
  clearTimeout(recoveryTimer);
  // Detach first: cancel restores the covered inline transform and can flash a live light panel.
  overlay?.remove();overlay=null;animations.forEach(a=>a.cancel());animations=[];
  navigating=false;root.classList.remove('route-holding','route-departing','route-arriving');
  document.querySelectorAll('.control-pressed,.control-feedback').forEach(el=>el.classList.remove('control-pressed','control-feedback'));
 };
 const frame=()=>new Promise(resolve=>requestAnimationFrame(resolve));
 const animate=(el,frames,options)=>{
  if(!el.animate)return Promise.resolve();
  const a=el.animate(frames,{...options,fill:'both'});animations.push(a);return a.finished.catch(()=>{});
 };
 const makeOverlay=(info,covered)=>{
  overlay=document.createElement('div');overlay.className='route-transition'+(info.light?' is-light':'');overlay.setAttribute('aria-hidden','true');
  overlay.innerHTML='<div class="route-panels"><i></i><i></i><i></i></div>';
  overlay.style.setProperty('--route-surface',info.surface);
  overlay.querySelectorAll('.route-panels i').forEach(el=>el.style.transform=covered?'translateY(0)':'translateY(101%)');

  document.body.append(overlay);return overlay;
 };
 try{
  const arrival=window.siteRouteArrival||JSON.parse(sessionStorage.getItem(key)||'null');
  sessionStorage.removeItem(key);
  window.siteInternalArrival=!!arrival&&arrival.url===location.href&&Date.now()-arrival.time<30000;
 }catch{window.siteInternalArrival=false}
 document.addEventListener('DOMContentLoaded',async()=>{
  clearTimeout(window.siteRouteHoldTimer);
  if(!window.siteInternalArrival||!enabled()){root.classList.remove('route-holding');return}
  root.classList.add('route-arriving');
  const layer=makeOverlay(describe(new URL(location.href)),true);
  // Full panels paint before the critical first-paint cover is removed.
  await frame();await frame();root.classList.remove('route-holding');
  const panels=[...layer.querySelectorAll('.route-panels i')];
  const motion=panels.map((el,i)=>animate(el,[{transform:'translateY(0)'},{transform:'translateY(-101%)'}],{duration:460,delay:40+i*45,easing:'cubic-bezier(.76,0,.24,1)'}));
  await Promise.all(motion);
  // Keep the document on its normal painted layer; only the shutters animate.
  // Persist their offscreen end state before detaching compositor layers.
  panels.forEach(el=>el.style.transform='translateY(-101%)');
  await frame();await frame();
  if(overlay===layer)reset();
 });
 // Keep the browser document alive: a full navigation can expose the host's white canvas.
 const loadPage=async url=>{
  const response=await fetch(url.href,{signal:AbortSignal.timeout(12000)});
  if(!response.ok||new URL(response.url).origin!==location.origin)throw Error('Page unavailable');
  const doc=new DOMParser().parseFromString(await response.text(),'text/html');
  if(!doc.querySelector('main')||!doc.querySelector('.header')||!window.sitePage)throw Error('Not a site page');
  const asset=doc.querySelector('script[src*="/assets/navigation.js"]')?.getAttribute('src');
  if(asset!==document.querySelector('script[src*="/assets/navigation.js"]')?.getAttribute('src'))throw Error('New site version');
  return doc;
 };
 const changePage=async(url,pop=false,position=[0,0])=>{
  if(navigating){if(pop)location.reload();return}
  stopScroll();reset();navigating=true;root.classList.add('route-departing');
  const info=describe(url),layer=makeOverlay(info,false);
  const pending=loadPage(url);pending.catch(()=>{});
  try{
   if(enabled())await Promise.all([...layer.querySelectorAll('i')].map((el,i)=>animate(el,[{transform:'translateY(101%)'},{transform:'translateY(0)'}],{duration:250,delay:i*40,easing:'cubic-bezier(.65,0,.25,1)'})));
   layer.querySelectorAll('i').forEach(el=>el.style.transform='translateY(0)');
   const doc=await pending;
   if(!pop){history.replaceState({...history.state,siteScroll:[scrollX,scrollY]},'',location.href);history.pushState({siteScroll:[0,0]},'',url.href)}
   documentURL=new URL(url.href);
   window.sitePage.unmount();
   document.title=doc.title;root.lang=doc.documentElement.lang;
   const meta='meta[name="description"],meta[property],meta[name^="twitter:"],link[rel="canonical"],link[rel="alternate"]';
   document.head.querySelectorAll(meta).forEach(el=>el.remove());
   doc.head.querySelectorAll(meta).forEach(el=>document.head.append(document.importNode(el,true)));
   document.body.className=doc.body.className;document.body.dataset.language=doc.body.dataset.language;
   root.style.background=info.surface;document.body.style.background=info.surface;
   root.style.colorScheme=info.light?'light':'dark';document.querySelector('meta[name="color-scheme"]').content=info.light?'light':'dark';
   document.body.replaceChildren(...[...doc.body.childNodes].map(el=>document.importNode(el,true)),layer);
   window.siteInternalArrival=true;
   window.scrollTo({left:position[0],top:position[1],behavior:'instant'});
   window.sitePage.mount();
   const target=url.hash?document.getElementById(decodeURIComponent(url.hash.slice(1))):null;
   if(target&&!pop)target.scrollIntoView({behavior:'instant',block:'start'});
   document.querySelector('main').focus({preventScroll:true});
   root.classList.remove('route-departing');root.classList.add('route-arriving');
   await frame();await frame();
   animations.forEach(a=>a.cancel());animations=[];
   const panels=[...layer.querySelectorAll('i')];
   if(enabled())await Promise.all(panels.map((el,i)=>animate(el,[{transform:'translateY(0)'},{transform:'translateY(-101%)'}],{duration:460,delay:40+i*45,easing:'cubic-bezier(.76,0,.24,1)'})));
   panels.forEach(el=>el.style.transform='translateY(-101%)');await frame();await frame();reset();
  }catch{
   // Preserve normal HTML navigation for errors, login redirects, or a newly deployed version.
   try{sessionStorage.setItem(key,JSON.stringify({url:url.href,time:Date.now(),surface:info.surface}))}catch{}
   location.assign(url.href);recoveryTimer=setTimeout(reset,7000);
  }
 };
 document.addEventListener('click',event=>{
  const a=event.target.closest?.('a[href]');
  if(!a||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||a.hasAttribute('download')||(a.target&&a.target!=='_self'))return;
  const url=new URL(a.href,location.href);
  if(url.origin!==location.origin||!/^https?:$/.test(url.protocol)||!/^\/(zh|en)\//.test(url.pathname)||/\.[a-z0-9]+$/i.test(url.pathname))return;
  event.preventDefault();
  if(navigating)return;
  if(sameDocument(url)){
   const oldURL=location.href;
   if(url.href!==oldURL){history.replaceState({...history.state,siteScroll:[scrollX,scrollY]},'',oldURL);history.pushState({siteScroll:[0,0]},'',url.href);window.dispatchEvent(new HashChangeEvent('hashchange',{oldURL,newURL:url.href}))}
   scrollWithin(url,[0,0]);return;
  }
  changePage(url);
 });
 window.addEventListener('popstate',event=>{
  const url=new URL(location.href),position=event.state?.siteScroll||[0,0];
  if(sameDocument(url)&&!navigating){scrollWithin(url,position);return}
  changePage(url,true,position);
 });
 window.addEventListener('pageshow',event=>{if(event.persisted)reset()});
})();
