(()=>{
let dispose=()=>{};
function mount(){
 dispose();
 const controller=new AbortController(),cleanup=[];
 const listen=(target,type,handler,options={})=>target?.addEventListener(type,handler,{...options,signal:controller.signal});
 dispose=()=>{controller.abort();cleanup.forEach(fn=>fn());document.querySelectorAll('[data-copy-email]').forEach(el=>clearTimeout(el._copyReset));};
const menu=document.querySelector('.menu');
const nav=document.querySelector('.nav');
const narrow=window.matchMedia('(max-width:800px)');
function closeMenu(restoreFocus=false){
  const wasOpen=menu?.getAttribute('aria-expanded')==='true';
  menu?.setAttribute('aria-expanded','false');
  nav?.classList.remove('open');
  if(wasOpen&&restoreFocus)menu.focus();
}
listen(menu,'click',()=>{
  const open=menu.getAttribute('aria-expanded')!=='true';
  menu.setAttribute('aria-expanded',String(open));
  nav?.classList.toggle('open',open);
  if(open)nav?.querySelector('a')?.focus();
});
listen(document,'keydown',event=>{
  if(event.key==='Escape')closeMenu(true);
});
listen(nav,'click',event=>{
  if(event.target.closest('a'))closeMenu();
});
listen(document,'click',event=>{
  if(!event.target.closest('.header'))closeMenu();
});
listen(narrow,'change',()=>closeMenu());
listen(document,'focusin',event=>{
  if(narrow.matches && menu?.getAttribute('aria-expanded')==='true' && !event.target.closest('.header'))closeMenu();
});
document.querySelectorAll('[data-lang]').forEach(a=>{
  const base=a.getAttribute('href');
  const syncHash=()=>{
    const shared=/^#(?:main|why|ip|home-exchange|community-events|lab|now|evidence|content-foundations|housing-context|community-connections|first-ai-edit|personal-website)$/;
    a.setAttribute('href',base+(shared.test(location.hash)?location.hash:''));
  };
  syncHash();
  listen(window,'hashchange',syncHash);
  listen(a,'click',()=>{try{localStorage.setItem('site-language',a.dataset.lang)}catch{}});
});
function revealTraceTarget(event){
  const id=location.hash.slice(1);
  const entry=id?document.getElementById(id):null;
  if(entry?.classList.contains('trace-entry')){
    const details=entry.querySelector('details');
    if(details)details.open=true;
    if(!event)requestAnimationFrame(()=>entry.scrollIntoView({block:'start',behavior:'instant'}));
  }
}
listen(window,'hashchange',revealTraceTarget);
revealTraceTarget();
const header=document.querySelector('.header');
function updateHeader(){header?.classList.toggle('compact',window.scrollY>30)}
listen(window,'scroll',updateHeader,{passive:true});
updateHeader();
document.querySelectorAll('.data-viewer').forEach(viewer=>{
 const tabs=[...viewer.querySelectorAll('[role=tab]')],panels=[...viewer.querySelectorAll('.data-panel')];let current=0,animation;
 const select=(index,focus=false)=>{
  const previous=current;current=index;animation?.cancel();
  tabs.forEach((tab,i)=>{tab.setAttribute('aria-selected',String(i===index));tab.tabIndex=i===index?0:-1;panels[i].hidden=i!==index});
  if(focus)tabs[index].focus();
  let pref='system';try{pref=localStorage.getItem('site-motion')||'system'}catch{}
  const enabled=pref==='on'||(pref!=='off'&&!matchMedia('(prefers-reduced-motion: reduce)').matches);
  if(enabled&&index!==previous)animation=panels[index].animate([{opacity:.35,transform:'translateX('+(index>previous?16:-16)+'px)'},{opacity:1,transform:'translateX(0)'}],{duration:280,easing:'cubic-bezier(.2,.7,.2,1)'});
 };
 viewer.classList.add('is-ready');select(0);
 tabs.forEach((tab,i)=>{listen(tab,'click',()=>select(i));listen(tab,'keydown',e=>{let next;if(e.key==='ArrowRight')next=(i+1)%tabs.length;if(e.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;if(e.key==='Home')next=0;if(e.key==='End')next=tabs.length-1;if(next!==undefined){e.preventDefault();select(next,true)}})});
 cleanup.push(()=>animation?.cancel());
});
const isHome=!!document.querySelector('.hero');
if(isHome)document.body.classList.add('home-motion');
if(window.gsap&&window.ScrollTrigger&&isHome){
  gsap.registerPlugin(ScrollTrigger);
  const systemMotion=window.matchMedia('(prefers-reduced-motion: reduce)');
  let motionPreference='system';
  try { const saved=localStorage.getItem('site-motion'); if(['system','on','off'].includes(saved))motionPreference=saved; } catch {}
  const isMotionEnabled=()=>motionPreference==='on'||(motionPreference==='system'&&!systemMotion.matches);
  const en=document.documentElement.lang==='en';
  const controls=[];
  document.querySelectorAll('.hero-bottom,.foot').forEach(host=>{
    const label=document.createElement('label');label.className='motion-control';
    const text=document.createElement('span');text.textContent=en?'Motion':'动效';
    const select=document.createElement('select');select.setAttribute('aria-label',en?'Motion preference':'动效设置');
    for(const [value,title] of [['system',en?'Follow system':'跟随系统'],['on',en?'On':'开启'],['off',en?'Off':'关闭']]){
      const option=document.createElement('option');option.value=value;option.textContent=title;select.append(option);
    }
    label.append(text,select);host.append(label);controls.push(select);
    listen(select,'change',()=>{motionPreference=select.value;try{localStorage.setItem('site-motion',motionPreference)}catch{};applyMotion();});
  });
  let media;
  let entryContext;
  let removeEntry=()=>{};
  function playEntry(force=false){
    removeEntry();entryContext?.revert();
    if(!isMotionEnabled()||(!force&&(location.hash||window.siteInternalArrival))||scrollY>80)return;
    const overlay=document.createElement('div');overlay.className='entry-loader';
    overlay.innerHTML=`<div class="entry-top"><span>XIE LINZHI</span><span>PORTFOLIO / 2026</span></div><div class="entry-center"><span class="entry-caption">${en?'ENTERING THE PORTFOLIO':'正在展开作品集'}</span><div class="entry-count" aria-hidden="true"><span>0</span><small>%</small></div><div class="entry-track"><i></i></div></div><div class="entry-bottom"><span>BUILD / UNDERSTAND / CONNECT</span><button type="button">${en?'Skip intro':'跳过入场'}</button></div>`;
    overlay.setAttribute('aria-label',en?'Portfolio introduction':'作品集入场');
    document.body.append(overlay);
    let timer;
    const finish=()=>{clearTimeout(timer);overlay.remove();document.removeEventListener('keydown',skipKey);window.removeEventListener('wheel',cancelEntrance);window.removeEventListener('touchmove',cancelEntrance);};
    const skipKey=e=>{if(e.key==='Escape'||e.key==='Tab'){entryContext?.revert();finish()}};
    removeEntry=()=>{entryContext?.revert();finish()};
    const cancelEntrance=()=>removeEntry();
    listen(overlay.querySelector('button'),'click',cancelEntrance);
    listen(document,'keydown',skipKey);listen(window,'wheel',cancelEntrance,{once:true});listen(window,'touchmove',cancelEntrance,{once:true});
    // This counter represents the entrance sequence, not fabricated download bytes.
    timer=setTimeout(removeEntry,4500);
    entryContext=gsap.context(()=>{
      const progress={value:0};
      const tl=gsap.timeline({onComplete:finish});
      tl.to(progress,{value:100,duration:1.35,ease:'power2.inOut',onUpdate:()=>{overlay.querySelector('.entry-count span').textContent=Math.round(progress.value);}})
        .fromTo(overlay.querySelector('.entry-track i'),{scaleX:0},{scaleX:1,duration:1.35,ease:'power2.inOut'},0)
        .to(overlay,{yPercent:-100,duration:.75,ease:'power3.inOut'},1.55)
        .from('.hero h1 > span',{yPercent:110,rotation:3,opacity:0,stagger:.13,duration:.95,ease:'power3.out',clearProps:'all'},1.8)
        .from('.hero .eyebrow,.hero-body,.hero-bottom',{y:35,opacity:0,stagger:.12,duration:.7,ease:'power2.out',clearProps:'all'},2.05);
    });
  }
  const replay=document.createElement('button');replay.className='entry-replay';replay.textContent=en?'Replay intro ↗':'重播入场 ↗';
  document.querySelector('.hero-bottom').append(replay);
  listen(replay,'click',()=>{if(!isMotionEnabled()){motionPreference='on';try{localStorage.setItem('site-motion','on')}catch{};applyMotion()}window.scrollTo({top:0,behavior:'instant'});playEntry(true)});
  function buildJourney(mobile){
    const main=document.querySelector('main');
    const sections=[...main.querySelectorAll(':scope > .hero,:scope > .chapter')];
    const labels=['ACTION','MEMORY','BUILD','UNDERSTAND','CONNECT','TOOLS','TRACE','LET’S TALK'];
    const ns='http://www.w3.org/2000/svg';
    const svg=document.createElementNS(ns,'svg');svg.classList.add('journey');svg.setAttribute('aria-hidden','true');
    const make=(tag,cls)=>{const el=document.createElementNS(ns,tag);el.setAttribute('class',cls);svg.append(el);return el};
    const base=make('path','journey-base'),ink=make('path','journey-ink');
    const stations=sections.map(()=>make('circle','journey-station'));
    const halo=make('circle','journey-halo'),head=make('circle','journey-head');
    halo.setAttribute('r',mobile?10:19);head.setAttribute('r',mobile?4:7);
    main.append(svg);
    const badge=document.createElement('div');badge.className='journey-badge';badge.setAttribute('aria-hidden','true');
    badge.innerHTML='<span class="journey-index"></span><span class="journey-label"></span><i></i>';
    document.body.append(badge);
    let points=[],length=0,maxScroll=1,origin=0;
    const state={progress:0};
    const paint=()=>{
      if(!length)return;
      const target=Math.min(points.at(-1).y,Math.max(points[0].y,state.progress*maxScroll+innerHeight*.52-origin));
      // Invert a monotonic path's Y position so the traveler stays in the reading viewport.
      let low=0,high=length;
      for(let i=0;i<15;i++){const mid=(low+high)/2;if(ink.getPointAtLength(mid).y<target)low=mid;else high=mid}
      const distance=(low+high)/2,point=ink.getPointAtLength(distance);
      ink.style.strokeDashoffset=String(length-distance);
      for(const el of [halo,head]){el.setAttribute('cx',point.x);el.setAttribute('cy',point.y)}
      let active=0;
      points.forEach((p,i)=>{const reached=target>=p.y-4;stations[i].classList.toggle('reached',reached);if(reached)active=i});
      badge.querySelector('.journey-index').textContent=String(active+1).padStart(2,'0')+' / 08';
      badge.querySelector('.journey-label').textContent=labels[active];
      badge.style.setProperty('--journey-progress',state.progress);
      badge.dataset.chapter=String(active);
      sections.forEach((el,i)=>el.classList.toggle('journey-current',i===active));
    };
    const measure=()=>{
      origin=main.getBoundingClientRect().top+scrollY;
      const width=main.clientWidth,height=main.offsetHeight;
      svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.style.height=height+'px';
      const gutter=mobile?9:Math.max(20,Math.min(44,parseFloat(getComputedStyle(sections[0]).paddingLeft)*.5));
      points=sections.map((section,i)=>({x:gutter,y:section.offsetTop-origin+(i===0?190:parseFloat(getComputedStyle(section).paddingTop)+10)}));
      let d=`M ${points[0].x} ${points[0].y}`;
      for(let i=1;i<points.length;i++){
        const a=points[i-1],b=points[i];
        const bridge=sections[i].previousElementSibling;
        if(bridge?.classList.contains('transition')){
          const top=bridge.offsetTop-origin,h=bridge.offsetHeight,midX=width*(mobile?.58:.76);
          d+=` L ${a.x} ${top} C ${a.x} ${top+h*.2} ${midX} ${top+h*.1} ${midX} ${top+h*.48} C ${midX} ${top+h*.87} ${b.x} ${top+h*.82} ${b.x} ${b.y}`;
        }else{
          const middle=(a.y+b.y)/2;
          d+=` C ${a.x} ${middle} ${b.x} ${middle} ${b.x} ${b.y}`;
        }
      }
      base.setAttribute('d',d);ink.setAttribute('d',d);length=ink.getTotalLength();ink.style.strokeDasharray=String(length);
      points.forEach((p,i)=>{stations[i].setAttribute('cx',p.x);stations[i].setAttribute('cy',p.y);stations[i].setAttribute('r',mobile?3:5)});
      maxScroll=ScrollTrigger.maxScroll(window);paint();
    };
    measure();
    gsap.to(state,{progress:1,ease:'none',scrollTrigger:{id:'homepage-journey',start:0,end:()=>ScrollTrigger.maxScroll(window),scrub:true,onRefresh:measure},onUpdate:paint});
    return ()=>{svg.remove();badge.remove();sections.forEach(el=>el.classList.remove('journey-current'))};
  }
  function applyMotion(){
    removeEntry();
    media?.revert();
    const enabled=isMotionEnabled();
    document.documentElement.dataset.motion=enabled?'on':'off';
    controls.forEach(select=>{
      select.value=motionPreference;
      select.options[0].textContent=en?`System (${systemMotion.matches?'off':'on'})`:`跟随系统（${systemMotion.matches?'已关闭':'已开启'}）`;
    });
    media=gsap.matchMedia();
    media.add({
    desktop:'(min-width:801px)',
    mobile:'(max-width:800px)',
    motion:'(prefers-reduced-motion: no-preference)'
  },context=>{
    if(!enabled)return;
    const mobile=context.conditions.mobile;
    // Each incoming chapter shares a timeline with the outgoing chapter.
    const chapters=[...document.querySelectorAll('.hero,.chapter')];
    chapters.slice(1).forEach((section,index)=>{
      const content=section.querySelector(':scope > .wrap');
      const previous=chapters[index].querySelector(':scope > .wrap');
      if(!content)return;
      const handoff=gsap.timeline({scrollTrigger:{id:'chapter-reveal-'+index,trigger:section,start:'top 98%',end:'top 30%',scrub:true,invalidateOnRefresh:true}});
      handoff.fromTo(content,{y:mobile?64:115},{y:0,duration:1,ease:'none'},0);
      if(previous)handoff.fromTo(previous,{scale:1},{scale:mobile?.98:.94,transformOrigin:'center bottom',duration:1,ease:'none',immediateRender:false},0);
    });
    const disposeJourney=buildJourney(mobile);
    document.querySelectorAll('.personal-photo,.home-evidence').forEach((figure,index)=>{
      gsap.fromTo(figure,{clipPath:'inset(14% 9% 14% 9%)',scale:.88},{clipPath:'inset(0% 0% 0% 0%)',scale:1,ease:'none',scrollTrigger:{id:'photo-reveal-'+index,trigger:figure.closest('.chapter'),start:'top 95%',end:'top 22%',scrub:true,invalidateOnRefresh:true}});
    });
    document.querySelectorAll('.transition').forEach((el,index)=>{
      let title=el.querySelector('.bridge-title');
      if(!title){title=document.createElement('span');title.className='bridge-title';title.textContent=index===0?'SELECTED WORK':'IDEAS INTO TOOLS';el.append(title)}
      gsap.fromTo(title,{xPercent:mobile?-12:-24,scale:.82},{xPercent:mobile?12:24,scale:1.08,ease:'none',scrollTrigger:{trigger:el,start:'top bottom',end:'bottom top',scrub:true}});
    });
    document.querySelectorAll('.diagram .wire').forEach(el=>{
      const length=el.getTotalLength();
      gsap.fromTo(el,{strokeDasharray:length,strokeDashoffset:length*.65},{
        strokeDashoffset:0,ease:'none',
        scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom 40%',scrub:true,invalidateOnRefresh:true}
      });
    });
    document.querySelectorAll('.chapter .flow').forEach(el=>gsap.from(el.children,{
      y:mobile?25:45,stagger:.08,ease:'none',
      scrollTrigger:{trigger:el,start:'top 90%',end:'top 45%',scrub:true,invalidateOnRefresh:true}
    }));
    // Decorative progress follows native scroll in both directions; text stays opaque.
    document.querySelectorAll('.transition').forEach((el,index)=>{
      const dot=el.querySelector('.traveler');
      const tl=gsap.timeline({scrollTrigger:{id:'chapter-transition-'+index,trigger:el,start:'top 85%',end:'bottom 15%',scrub:true,invalidateOnRefresh:true}});
      tl.fromTo(el,{'--bridge-progress':0},{'--bridge-progress':1,ease:'none'},0);
      if(dot)tl.fromTo(dot,{y:()=>-el.clientHeight*.30,scale:.8},{y:()=>el.clientHeight*.30,scale:1.15,ease:'none'},0);
    });
    document.querySelectorAll('.chapter .flow,.timeline').forEach((el,index)=>{
      gsap.fromTo(el,{'--trace-progress':0},{'--trace-progress':1,ease:'none',scrollTrigger:{id:'trace-line-'+index,trigger:el,start:'top 85%',end:mobile?'bottom 65%':'top 45%',scrub:true,invalidateOnRefresh:true}});
    });
    document.querySelectorAll('.project-notes').forEach((panel,index)=>{
      const tl=gsap.timeline({scrollTrigger:{id:'project-notes-'+index,trigger:panel,start:'top 92%',end:'bottom 65%',scrub:true,invalidateOnRefresh:true}});
      panel.querySelectorAll('.project-note').forEach((row,i)=>{
        tl.fromTo(row.querySelector('div'),{y:22},{y:0,ease:'none',duration:1},i*.22);
        tl.fromTo(row.querySelector('i'),{scaleX:0},{scaleX:1,ease:'none',duration:1},i*.22);
      });
    });
    document.querySelectorAll('.project-word').forEach(el=>gsap.from(el,{
      x:mobile?-32:-115,y:mobile?18:0,ease:'none',
      scrollTrigger:{trigger:el,start:'top 90%',end:'top 55%',scrub:true,invalidateOnRefresh:true}
    }));
    document.querySelectorAll('#lab .row').forEach(el=>gsap.from(el,{
      y:mobile?24:48,ease:'none',scrollTrigger:{trigger:el,start:'top 95%',end:'top 72%',scrub:true,invalidateOnRefresh:true}
    }));
    document.querySelectorAll('.timeline').forEach(el=>gsap.from(el.children,{
      y:mobile?24:48,stagger:.08,ease:'none',
      scrollTrigger:{trigger:el,start:'top 85%',end:'bottom 65%',scrub:true,invalidateOnRefresh:true}
    }));
    document.querySelectorAll('.now-note').forEach(el=>gsap.from(el,{
      y:mobile?24:48,ease:'none',
      scrollTrigger:{trigger:el,start:'top 90%',end:'top 60%',scrub:true,invalidateOnRefresh:true}
    }));
    return disposeJourney;
  });
  }
  applyMotion();
  playEntry();
  listen(systemMotion,'change',()=>{if(motionPreference==='system')applyMotion()});
  let refreshFrame;
  const refresh=()=>{
    if(controller.signal.aborted)return;
    cancelAnimationFrame(refreshFrame);
    refreshFrame=requestAnimationFrame(()=>ScrollTrigger.refresh());
  };
  document.querySelectorAll('img').forEach(img=>{if(!img.complete)listen(img,'load',refresh,{once:true})});
  listen(window,'load',refresh,{once:true});
  document.fonts?.ready.then(refresh);
  cleanup.push(()=>{removeEntry();media?.revert();cancelAnimationFrame(refreshFrame)});
}

document.querySelectorAll('[data-copy-email]').forEach(button=>{
 button.hidden=false;
 listen(button,'click',async()=>{
  const status=button.parentElement.querySelector('.copy-status');
  const en=document.documentElement.lang==='en';
  try{
   if(!navigator.clipboard?.writeText)throw Error('Clipboard unavailable');
   await navigator.clipboard.writeText(button.dataset.copyEmail);
   status.textContent=en?'Email address copied.':'邮箱已复制。';
   const label=button.dataset.originalLabel||(button.dataset.originalLabel=button.textContent);
   clearTimeout(button._copyReset);
   button.textContent=en?'Copied ✓':'已复制 ✓';button.classList.add('copy-confirmed');
   button._copyReset=setTimeout(()=>{button.textContent=label;button.classList.remove('copy-confirmed')},2200);
  }catch{
   status.textContent=en?'Please select and copy the email address above.':'请选中上方邮箱地址手动复制。';
  }
 });
});

// Controls respond without delaying navigation or animating reading content.
(function installControlFeedback(){
  const root=document.documentElement;
  const system=matchMedia('(prefers-reduced-motion: reduce)');
  const sync=()=>{let preference='system';try{preference=localStorage.getItem('site-motion')||'system'}catch{};root.dataset.uiMotion=preference==='on'||(preference!=='off'&&!system.matches)?'on':'off'};
  sync();listen(system,'change',sync);listen(window,'storage',sync);
  listen(document,'change',event=>{if(event.target.closest('.motion-control'))sync()});
  const selector='a[href],button,summary';
  const targetOf=event=>{const el=event.target.closest?.(selector);return el&&!el.matches(':disabled,[aria-disabled="true"]')?el:null};
  let pressed=null;
  const clear=()=>{pressed?.classList.remove('control-pressed');pressed=null};
  listen(document,'pointerdown',event=>{if(event.button!==0)return;clear();pressed=targetOf(event);pressed?.classList.add('control-pressed')});
  listen(document,'pointerup',clear);listen(document,'pointercancel',clear);listen(window,'blur',clear);
  listen(document,'keydown',event=>{if(event.repeat)return;const el=targetOf(event);if(el&&(event.key==='Enter'||(event.key===' '&&!el.matches('a')))){clear();pressed=el;el.classList.add('control-pressed')}});
  listen(document,'keyup',clear);
  listen(document,'focusout',clear);
  const timers=new WeakMap();
  listen(document,'click',event=>{
    const el=targetOf(event);if(!el)return;
    if(root.dataset.uiMotion==='on'){
      const rect=el.getBoundingClientRect();
      const pulse=document.createElement('i');pulse.className='click-pulse';pulse.setAttribute('aria-hidden','true');
      pulse.style.left=(event.detail?event.clientX:rect.x+rect.width/2)+'px';
      pulse.style.top=(event.detail?event.clientY:rect.y+rect.height/2)+'px';
      document.body.append(pulse);setTimeout(()=>pulse.remove(),520);
    }
    clearTimeout(timers.get(el));el.classList.remove('control-feedback');
    // Restart feedback for a repeated tap; no default action is intercepted.
    void el.offsetWidth;el.classList.add('control-feedback');
    timers.set(el,setTimeout(()=>el.classList.remove('control-feedback'),360));
  });
})();

}
window.sitePage={mount,unmount:()=>dispose()};
mount();
})();
