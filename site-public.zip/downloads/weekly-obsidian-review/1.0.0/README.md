# Weekly Knowledge Review 1.0.0 · 试用版

作者：谢林志 / Xie Linzhi

## 安装

1. 解压并保留文件夹结构。
2. 将整个文件夹放入你使用的 AI 助手支持的本地 skills 目录；也可以直接让助手读取本包 SKILL.md。
3. 按下方依赖准备环境，指定自己的工作目录，用一个小样本验证后再批量运行。升级时替换技能文件夹，业务数据留在独立目录。

## 环境要求

Codex 桌面环境及任务读取/本地文件权限。Obsidian 可选；定时运行需要宿主支持自动化。

## 开始使用

对助手说：“使用这个 Skill，整理我选择的本周任务，保存到我指定的知识库。先列出覆盖范围。”首次先手动试跑，再按自己选择的时间设定自动整理。

## 使用许可

非商业用途可下载、修改、部署与分享，保留谢林志署名；任何商业使用须事先取得作者书面许可。联系 1106560592@qq.com。完整条款见 LICENSE.md；第三方内容按 THIRD_PARTY_NOTICES.md 中原许可执行。

## English

Extract the whole folder and ask your compatible local-file AI assistant to read SKILL.md. Install the documented dependencies separately and choose your own workspace. Keep work data outside the skill folder when upgrading. Noncommercial use is permitted with attribution to Xie Linzhi; commercial use requires prior written permission. Third-party terms remain unchanged.
