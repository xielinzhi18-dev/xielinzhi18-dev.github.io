# Xie Linzhi Noncommercial License 1.0

Copyright (c) 2026 谢林志 / Xie Linzhi. 保留未明确授予的权利。
适用范围：谢林志原创工作流与脚本，1.0.0。生效日期：2026-09-17。
许可标识：LicenseRef-Xie-Linzhi-Noncommercial-1.0（自定义许可，非 OSI 开源许可）。

## 中文条款（解释冲突时以中文为准）

1. 许可范围：在许可人拥有并有权授权的本包代码和文档范围内，允许你为非商业目的下载、复制、学习、运行、修改、自行部署，以及分享原版或修改版。本许可不转让著作权，也不授予商标或代言权。
2. 商业使用必须事先取得谢林志 / Xie Linzhi 的明确书面许可（包括可留存的电子书面许可），并遵守该许可约定的用途、期限和其他条件。没有取得许可时，不得商用。下载、保留署名或支付第三方运行费用，均不自动取得商用许可。
3. 商业使用包括：用于公司、品牌、雇主或客户的商业运营（包括内部使用）；有偿服务、商业推广、营销、达人投放、销售获客；出售、出租或付费分发本包或修改版；将其作为收费产品、服务或可产生广告、佣金等收益的服务的一部分。即使工具本身免费、项目尚未盈利，仍可能属于上述商业使用。个人学习、研究、非商业实验和不获取商业利益的分享属于允许范围。
4. 署名与分享：所有副本或实质部分须保留“谢林志 / Xie Linzhi”版权署名、本许可全文及已有第三方声明。非商业分享须将本许可随包提供，并让接收方知道商用须另获作者许可；不得声称你是原作者或改变原有部分的许可。修改版应说明修改者及主要变化；修改者可以署名自己的新增贡献，但不能删除原作者署名。可以直接分享作者的原始下载链接。
5. 第三方内容按其原有许可执行，本许可不覆盖或限制其独立权利。包外的 Python、AI 助手及其他服务不包含在本授权中。运行所需账号和服务须按各自规则取得。
6. 不授予未明确列出的权利；额外的商业授权须由谢林志 / Xie Linzhi 单独明确授予，非商业分享者无权代表作者批准商用。
7. 本包按现状提供，无适用性、可靠性或无错误保证；在适用法律允许范围内，许可人不承担因使用产生的损失责任。本条不排除法律规定不能排除的权利或责任。
8. 违反条款的使用不在授权范围内，应立即停止相关使用或分发。另行获得的有效商业许可按其约定执行。

## English terms

The Chinese terms govern if interpretations differ.
You may download, copy, study, run, modify, self-host and share original or modified copies of the covered code and documentation for noncommercial purposes only.
Commercial use requires prior explicit written permission from 谢林志 / Xie Linzhi, including retained electronic written permission, and is limited to its scope and conditions.
Commercial use includes business operations for a company, brand, employer or client (including internal use), paid services, commercial promotion, marketing, creator campaigns, sales generation, sale or rental of this package or a derivative, and inclusion in paid, advertising-supported or commission-generating products or services. Free access or absence of profit does not waive these restrictions. Personal learning, research, noncommercial experiments and sharing without commercial benefit are permitted.
Retain the copyright credit 谢林志 / Xie Linzhi, this full license and existing third-party notices in copies or substantial portions. Include this license with noncommercial redistribution and inform recipients that commercial use requires separate author permission. Mark modifications and their author without removing original attribution. Do not claim original authorship or relicense the original portions. Sharing the original download link is permitted.
Third-party components retain their own licenses. This license grants only rights the licensor holds in covered material; it does not cover external Python distributions, AI assistants, trademarks, endorsements or third-party services.
No unlisted rights are granted. Redistributors cannot grant commercial permission on behalf of the author. The package is provided as-is without warranties, with liability excluded to the extent permitted by applicable law. Noncompliant use is outside this grant and must cease. A separately granted commercial license is governed by its own terms.
