# Video Editing Workflow 1.0.0 · 试用版

作者：谢林志 / Xie Linzhi

## 安装

1. 解压并保留文件夹结构。
2. 将整个文件夹放入你使用的 AI 助手支持的本地 skills 目录；也可以直接让助手读取本包 SKILL.md。
3. 按下方依赖准备环境，指定自己的工作目录，用一个小样本验证后再批量运行。升级时替换技能文件夹，业务数据留在独立目录。

## 环境要求

Python 3.11+；`python -m pip install -r requirements.txt`；FFmpeg/ffprobe 可从命令行调用；单独安装 HyperFrames（https://github.com/heygen-com/hyperframes）。需要使用者自己的转写通道或可靠字词时间文件。

## 开始使用

命令：`python local/launch.py --help`，`python local/launch.py classify video.mp4`。让助手读取 SKILL.md，并提供素材、输出位置与转写选择。
火山语音可用环境变量 VOLC_ASR_API_KEY 或本包根目录私有 .env 配置；没有上传与费用许可不要运行 transcribe。免费本地转写：`python local/launch.py transcribe-local video.mp4 --model 本地Whisper模型目录 --edit-dir ./edit`。使用 faster-whisper 格式的模型，模型单独下载。软件安装和模型下载完成后，此命令离线运行。
最近两条口播完成导出及字幕修订；技术检查与画面检查已有记录，最终听审由使用者完成。

## 使用许可

非商业用途可下载、修改、部署与分享，保留谢林志署名；任何商业使用须事先取得作者书面许可。联系 1106560592@qq.com。完整条款见 LICENSE.md；第三方内容按 THIRD_PARTY_NOTICES.md 中原许可执行。

## English

Extract the whole folder and ask your compatible local-file AI assistant to read SKILL.md. Install the documented dependencies separately and choose your own workspace. Keep work data outside the skill folder when upgrading. Noncommercial use is permitted with attribution to Xie Linzhi; commercial use requires prior written permission. Third-party terms remain unchanged.
