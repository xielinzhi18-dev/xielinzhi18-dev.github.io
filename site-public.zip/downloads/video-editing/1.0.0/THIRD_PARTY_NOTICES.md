# Third-party notices

helpers/ 来自 Browser Use video-use（MIT），包括本地适配；原版权及完整条款见 LICENSE-video-use-MIT.txt。本包不能用自定义非商业许可取消上游 MIT 权利。
local/、原创流程编排和新增文档按 LICENSE.md；HyperFrames、Python、FFmpeg、依赖库和模型独立安装并保留各自许可。本包不包含原始视频、账号、API 凭据、音乐或第三方模型。
