# KOL Operations 1.0.0 · 试用版

作者：谢林志 / Xie Linzhi

## 安装

1. 解压并保留文件夹结构。
2. 将整个文件夹放入你使用的 AI 助手支持的本地 skills 目录；也可以直接让助手读取本包 SKILL.md。
3. 按下方依赖准备环境，指定自己的工作目录，用一个小样本验证后再批量运行。升级时替换技能文件夹，业务数据留在独立目录。

## 环境要求

兼容本地 Skill 的 AI 助手；Python 3.10+，脚本只依赖标准库。

## 开始使用

示例：
```text
python scripts/kol_ops.py --root ./demo-data init --mode simulation
python scripts/kol_ops.py --root ./demo-data status
```
先用模拟资料演练；真实台账另建目录。草稿由使用者审核发送。

## 使用许可

非商业用途可下载、修改、部署与分享，保留谢林志署名；任何商业使用须事先取得作者书面许可。联系 1106560592@qq.com。完整条款见 LICENSE.md；第三方内容按 THIRD_PARTY_NOTICES.md 中原许可执行。

## English

Extract the whole folder and ask your compatible local-file AI assistant to read SKILL.md. Install the documented dependencies separately and choose your own workspace. Keep work data outside the skill folder when upgrading. Noncommercial use is permitted with attribution to Xie Linzhi; commercial use requires prior written permission. Third-party terms remain unchanged.
