# Topic Research 1.0.0 · 试用版

作者：谢林志 / Xie Linzhi

## 安装

1. 解压并保留文件夹结构。
2. 将整个文件夹放入你使用的 AI 助手支持的本地 skills 目录；也可以直接让助手读取本包 SKILL.md。
3. 按下方依赖准备环境，指定自己的工作目录，用一个小样本验证后再批量运行。升级时替换技能文件夹，业务数据留在独立目录。

## 环境要求

Python 3.11+；浏览器访问相应平台。小红书自动采集需单独安装 xpzouying/xiaohongshu-mcp 并登录；本地转写需 faster-whisper 及模型。工具和模型未打包。

## 开始使用

先运行 `python scripts/setup.py ./research-data`，再运行 `python scripts/benchmark.py --workspace ./research-data init --keyword 你的关键词`。
本地转写：`python scripts/transcribe-local.py audio.wav --output transcript.json --model 模型目录`。用 transcript-import 导入结果；如需启用 transcribe-local 统一命令，在工作目录 config/defaults.json 配置 local_asr 的 python、script、model、output_root。所有路径使用本机实际位置。
核心导出为结构化记录和 HTML 阅读索引；Excel 可交给当前助手的表格工具生成。

## 使用许可

非商业用途可下载、修改、部署与分享，保留谢林志署名；任何商业使用须事先取得作者书面许可。联系 1106560592@qq.com。完整条款见 LICENSE.md；第三方内容按 THIRD_PARTY_NOTICES.md 中原许可执行。

## English

Extract the whole folder and ask your compatible local-file AI assistant to read SKILL.md. Install the documented dependencies separately and choose your own workspace. Keep work data outside the skill folder when upgrading. Noncommercial use is permitted with attribution to Xie Linzhi; commercial use requires prior written permission. Third-party terms remain unchanged.
